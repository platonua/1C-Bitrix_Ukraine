<?
$arModuleVersion = array(
	"VERSION" => "1.0.1",
	"VERSION_DATE" => "2016-11-01 10:00:00"
);
?>